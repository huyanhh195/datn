#!/usr/bin/env python3
import rospy
from tf.broadcaster import TransformBroadcaster
from nav_msgs.msg import Odometry
import tf
from tf.transformations import euler_from_quaternion

def handleOdometry(msg):
    br = TransformBroadcaster()
    pos = msg.pose.pose.position
    ori = msg.pose.pose.orientation
    
    br.sendTransform((pos.x, pos.y, 0),
        (0, 0, ori.z, ori.w),
                     rospy.Time.now(),
                     "base_footprint",
                     "odom")


if __name__ == '__main__':
    print("state..")
    rospy.init_node('tf_broadcaster_odom')
    rospy.Subscriber('/odom', Odometry, handleOdometry)
    rospy.spin()
